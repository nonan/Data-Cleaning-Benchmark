DROP TABLE VoteIndiv;
DROP TABLE Vote;
DROP TABLE MParl;
DROP TABLE Parl;
DROP TABLE MP;
DROP TABLE Bill;
DROP TABLE Education;

CREATE TABLE MP (
  mp_id varchar(20) NOT NULL,
  name varchar(120) NOT NULL,
  gender varchar(10) NOT NULL,
  occupation varchar(120) NOT NULL,
  PRIMARY KEY (mp_id)
);

CREATE TABLE Parl (
  p_id mediumint(8) NOT NULL,
  bdate date,
  edate date,
  PRIMARY KEY (p_id)
);

CREATE TABLE MParl (
  mp_id varchar(20) NOT NULL,
  p_id mediumint(8) NOT NULL,
  paffiliation varchar(120) NOT NULL,
  constituency varchar(120) NOT NULL,
  electiond date,
  PRIMARY KEY (mp_id, p_id)
);

CREATE TABLE Education (
  mp_id varchar(20) NOT NULL,
  degree varchar(120) NOT NULL,
  PRIMARY KEY(mp_id, degree), 
  FOREIGN KEY(mp_id) REFERENCES MP(mp_id)
);

CREATE TABLE Bill (
    bill_id integer NOT NULL,
    bill_no varchar(20) NOT NULL,
    bill_title TEXT NOT NULL,
    sponsor_id integer,
    sponsor_name varchar(120) NOT NULL,
    sponsor_affiliation varchar(120) NOT NULL,
    p_id mediumint(8) NOT NULL,
    session_id mediumint(8) NOT NULL,
    intro_d date,
    updated_d date,
    bill_type varchar(120),  
    PRIMARY KEY(bill_id)
);

CREATE TABLE Vote (
  vote_id integer NOT NULL,
  p_id mediumint(8) NOT NULL,
  session_id mediumint(8) NOT NULL,
  dec_div mediumint(8) NOT NULL,
  bill_no varchar(20),
  bill_name varchar(120),
  doc_name varchar(120),
  yea varchar(20) NOT NULL,
  nay varchar(20) NOT NULL,
  yeas mediumint(8) NOT NULL,
  nays mediumint(8) NOT NULL,
  dec_result varchar(20) NOT NULL,
  dec_d date,  
  PRIMARY KEY(vote_id)
);

CREATE TABLE VoteIndiv (
  mp_id varchar(20),
  name varchar(120) NOT NULL,
  constituency varchar(120),
  vote_id integer NOT NULL,
  vote_v varchar(20) NOT NULL,
  PRIMARY KEY(vote_id, name),
  FOREIGN KEY(vote_id) REFERENCES Vote(vote_id)
);